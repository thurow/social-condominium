### Images folder
Holds all images for the applications.